import React from 'react'

const LowerBody =()=>{
return(
    <>
    </>
)

}
export default LowerBody