
//create custom module
exports.myDateTime = function () {
    return Date();
  };
  
  